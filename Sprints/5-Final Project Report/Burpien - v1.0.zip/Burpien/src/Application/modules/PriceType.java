package Application.modules;

public enum PriceType {
	Unit,
	Weight
}
