package Application.modules;

public enum Privilage {
	Root,
	SuperVisor,
	Employee,
}
